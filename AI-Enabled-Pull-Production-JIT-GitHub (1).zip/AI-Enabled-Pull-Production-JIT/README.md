# AI-Enabled Pull Production (JIT) — ANN + Explainable Fuzzy (Single File)

This project provides an **industry-style decision support system** for **Pull Production / JIT**:
- **Predictive layer (ANN):** predicts cycle time (`cycle_time_min`)
- **Prescriptive layer (Explainable Fuzzy):** generates pull decisions (**No / Partial / Full**) with **reasons** and **recommended actions**

## Inputs (place in the same folder)
- `pull_production_mes_data_10000.csv`
- `pull_decision_data_10000.csv`

## Run
```bash
pip install numpy pandas scikit-learn
python ai_jit_pull_single_file.py
```

## Outputs
- `ann_cycle_time_predictions.csv`
- `fuzzy_pull_predictions_explainable.csv`

## Key Output Columns
- `ann_predicted_cycle_time_min` — ANN prediction
- `pull_score_0_100` — 0–100 decision score
- `fuzzy_predicted_pull_decision` — No/Partial/Full Pull
- `decision_reason` — explainable trace (why)
- `recommended_action` — operator-ready action (what to do)

## Notes
- Leakage columns are removed for realistic prediction.
- Thresholds (`t_long`, `t_very_long`) are computed from data percentiles for robustness.
