# ============================================================
# AI-Enabled Pull Production (JIT) — SINGLE FILE (ANN + Explainable Fuzzy)
# Predictive: ANN predicts cycle time
# Prescriptive: Explainable fuzzy rules output pull decision + reasons + actions
#
# INPUT FILES (same folder):
#   pull_production_mes_data_10000.csv
#   pull_decision_data_10000.csv
#
# OUTPUT FILES:
#   ann_cycle_time_predictions.csv
#   fuzzy_pull_predictions_explainable.csv
# ============================================================

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import (
    mean_absolute_error, mean_squared_error, r2_score,
    classification_report, confusion_matrix
)

# ----------------------------
# CONFIG
# ----------------------------
SEED = 42
MES_CSV = "pull_production_mes_data_10000.csv"
PULL_CSV = "pull_decision_data_10000.csv"

OUT_ANN = "ann_cycle_time_predictions.csv"
OUT_PULL = "fuzzy_pull_predictions_explainable.csv"


# ============================================================
# 1) LOAD DATA
# ============================================================
df_mes = pd.read_csv(MES_CSV)
df_pull = pd.read_csv(PULL_CSV)

print("MES dataset:", df_mes.shape)
print("Pull dataset:", df_pull.shape)


# ============================================================
# 2) ANN: Predict cycle_time_min
# ============================================================
target = "cycle_time_min"

# Remove ID + target + leakage (recommended)
leakage_cols = ["queue_delay_min", "breakdown_delay_min", "setup_time_min"]
drop_cols = ["order_id", target] + [c for c in leakage_cols if c in df_mes.columns]

X = df_mes.drop(columns=drop_cols, errors="ignore")
y = df_mes[target].astype(float)

# Split by type
cat_cols = X.select_dtypes(include=["object"]).columns.tolist()
num_cols = [c for c in X.columns if c not in cat_cols]

# OneHotEncoder compatibility (old/new sklearn)
try:
    ohe = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
except TypeError:
    ohe = OneHotEncoder(handle_unknown="ignore", sparse=False)

preprocess = ColumnTransformer(
    transformers=[
        ("num", StandardScaler(), num_cols),
        ("cat", ohe, cat_cols),
    ]
)

ann = MLPRegressor(
    hidden_layer_sizes=(96, 48),
    activation="relu",
    solver="adam",
    learning_rate_init=0.001,
    max_iter=700,
    random_state=SEED,
    early_stopping=True,
    validation_fraction=0.15,
    n_iter_no_change=25
)

model = Pipeline(steps=[("prep", preprocess), ("ann", ann)])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=SEED
)

model.fit(X_train, y_train)
pred_test = model.predict(X_test)

mae = mean_absolute_error(y_test, pred_test)
rmse = float(np.sqrt(mean_squared_error(y_test, pred_test)))
r2 = r2_score(y_test, pred_test)

print("\n=== ANN Cycle Time Prediction Results ===")
print(f"MAE : {mae:.2f} min")
print(f"RMSE: {rmse:.2f} min")
print(f"R2  : {r2:.3f}")

# Predict for all orders (feed fuzzy)
df_mes["ann_predicted_cycle_time_min"] = model.predict(X)

# Save ANN predictions
df_mes[["order_id", "cycle_time_min", "ann_predicted_cycle_time_min"]].to_csv(OUT_ANN, index=False)
print(f"\nSaved ANN output -> {OUT_ANN}")


# ============================================================
# 3) EXPLAINABLE FUZZY DECISION + ACTION RECOMMENDATION
# ============================================================
df_merge = df_pull.merge(
    df_mes[["order_id", "ann_predicted_cycle_time_min"]],
    on="order_id",
    how="left"
)

# Robust dynamic thresholds from your data
t_long = float(np.nanpercentile(df_merge["ann_predicted_cycle_time_min"], 70))
t_very_long = float(np.nanpercentile(df_merge["ann_predicted_cycle_time_min"], 90))

def action_recommendation(label, pred_ct, wip, urg, qual, t_long, t_very_long):
    """Return practical operator/scheduler actions."""
    actions = []

    if qual == "Fail":
        actions += [
            "Stop pull for this order; quarantine/hold material.",
            "Run quality investigation (root cause + inspection sampling).",
            "Check machine condition & recent alarms; verify calibration/SPC limits."
        ]
        return " | ".join(actions)

    if wip >= 18:
        actions += [
            "Reduce WIP: limit release of new orders (tighten Kanban/WIP cap).",
            "Prioritize bottleneck clearing; rebalance line or add temporary capacity."
        ]
    elif wip <= 8 and urg == "High":
        actions += [
            "Expedite: release order now and prioritize dispatching at next station."
        ]

    if pred_ct >= t_very_long:
        actions += [
            "Investigate long cycle drivers: setup, changeover, downtime, staffing.",
            "Apply SMED/standard work to reduce setup variation."
        ]
    elif pred_ct >= t_long:
        actions += [
            "Monitor cycle time closely; verify tools/material availability to avoid waiting."
        ]

    if qual == "Rework":
        actions += [
            "Increase in-process checks; fix rework cause before full release."
        ]

    if not actions:
        actions += ["Proceed as planned; continue monitoring WIP and cycle time."]

    # Align with decision
    if label == "No Pull":
        actions.insert(0, "Do not pull; stabilize process first.")
    elif label == "Partial Pull":
        actions.insert(0, "Pull partially; release limited quantity and monitor.")
    else:
        actions.insert(0, "Full pull approved; release order to maintain JIT flow.")

    return " | ".join(actions)

def decide_with_explain(pred_ct, wip, urg, qual, t_long, t_very_long):
    """
    Returns:
      score_0_100, label, reason, action, factors(dict)
    """
    # Hard block (safety/quality)
    if qual == "Fail":
        score = 0.0
        label = "No Pull"
        reason = "No Pull because Quality=Fail (hard safety block)."
        action = action_recommendation(label, pred_ct, wip, urg, qual, t_long, t_very_long)
        factors = {
            "wip_penalty": None,
            "cycle_time_penalty": None,
            "urgency_boost": None,
            "quality_penalty": "Fail block",
            "final_score": score
        }
        return score, label, reason, action, factors

    score = 50.0
    reasons = []
    factors = {}

    # WIP penalty
    wip_norm = float(np.clip(wip / 30.0, 0.0, 1.0))
    wip_pen = 35.0 * wip_norm
    score -= wip_pen
    factors["wip_penalty"] = round(wip_pen, 2)

    if wip >= 18:
        reasons.append(f"WIP high ({wip}) reduces pull.")
    elif wip <= 8:
        reasons.append(f"WIP low ({wip}) supports pull.")
    else:
        reasons.append(f"WIP medium ({wip}) moderate impact.")

    # Cycle time penalty
    ct_pen = 0.0
    if pred_ct >= t_very_long:
        ct_pen = 20.0
        reasons.append(f"Predicted cycle time VERY LONG ({pred_ct:.1f} ≥ {t_very_long:.1f}).")
    elif pred_ct >= t_long:
        ct_pen = 10.0
        reasons.append(f"Predicted cycle time LONG ({pred_ct:.1f} ≥ {t_long:.1f}).")
    else:
        reasons.append(f"Predicted cycle time OK ({pred_ct:.1f}).")

    score -= ct_pen
    factors["cycle_time_penalty"] = round(ct_pen, 2)

    # Urgency boost
    if urg == "High":
        urg_boost = 20.0
        reasons.append("Urgency HIGH boosts pull.")
    elif urg == "Medium":
        urg_boost = 8.0
        reasons.append("Urgency MEDIUM slight boost.")
    else:
        urg_boost = 0.0
        reasons.append("Urgency LOW no boost.")

    score += urg_boost
    factors["urgency_boost"] = round(urg_boost, 2)

    # Quality penalty for rework
    q_pen = 0.0
    if qual == "Rework":
        q_pen = 12.0
        score -= q_pen
        reasons.append("Quality REWORK adds caution penalty.")
    else:
        reasons.append("Quality PASS no penalty.")

    factors["quality_penalty"] = round(q_pen, 2)

    # Clamp
    score = float(np.clip(score, 0, 100))
    factors["final_score"] = round(score, 2)

    # Score -> label
    if score < 35:
        label = "No Pull"
    elif score < 75:
        label = "Partial Pull"
    else:
        label = "Full Pull"

    # Reason summary
    reason = (
        f"{label} (score={score:.1f}). "
        f"WIP penalty={wip_pen:.1f}, CT penalty={ct_pen:.1f}, Urgency boost={urg_boost:.1f}, Quality penalty={q_pen:.1f}. "
        + " | ".join(reasons)
    )

    action = action_recommendation(label, pred_ct, wip, urg, qual, t_long, t_very_long)

    return score, label, reason, action, factors

# Run decision engine
scores, labels, reasons, actions, factors_list = [], [], [], [], []

for pred_ct, wip, urg, qual in zip(
    df_merge["ann_predicted_cycle_time_min"].values,
    df_merge["wip_level"].values,
    df_merge["demand_urgency"].astype(str).values,
    df_merge["quality_status"].astype(str).values
):
    s, lab, rsn, act, fac = decide_with_explain(float(pred_ct), int(wip), urg, qual, t_long, t_very_long)
    scores.append(s)
    labels.append(lab)
    reasons.append(rsn)
    actions.append(act)
    factors_list.append(fac)

df_merge["pull_score_0_100"] = np.round(scores, 2)
df_merge["fuzzy_predicted_pull_decision"] = labels
df_merge["decision_reason"] = reasons
df_merge["recommended_action"] = actions

# NOTE: Keep this in CSV for traceability. For production, store as JSON column.
df_merge["decision_factors_dict"] = factors_list  # will stringify when saving CSV


# ============================================================
# 4) EVALUATE + SAVE
# ============================================================
print("\n=== Class Distribution (True labels) ===")
print(df_merge["pull_decision"].value_counts())

print("\n=== Pull Decision Evaluation (Fuzzy vs Labeled) ===")
print(classification_report(df_merge["pull_decision"], df_merge["fuzzy_predicted_pull_decision"]))

labels_order = ["No Pull", "Partial Pull", "Full Pull"]
cm = confusion_matrix(df_merge["pull_decision"], df_merge["fuzzy_predicted_pull_decision"], labels=labels_order)
print("\nConfusion Matrix (rows=true, cols=pred):")
print(pd.DataFrame(
    cm,
    index=[f"true_{x}" for x in labels_order],
    columns=[f"pred_{x}" for x in labels_order]
))

# Save final file
df_merge.to_csv(OUT_PULL, index=False)
print(f"\nSaved -> {OUT_PULL}")

print("\n=== Sample Explainable Rows ===")
print(df_merge[[
    "order_id",
    "ann_predicted_cycle_time_min",
    "wip_level",
    "demand_urgency",
    "quality_status",
    "pull_score_0_100",
    "fuzzy_predicted_pull_decision",
    "decision_reason",
    "recommended_action"
]].head(8))

print("\nDONE ✅")
